﻿namespace NadekoBot.Modules.Games.Common.Hangman
{
    public enum Phase
    {
        Active,
        Ended,
    }
}
