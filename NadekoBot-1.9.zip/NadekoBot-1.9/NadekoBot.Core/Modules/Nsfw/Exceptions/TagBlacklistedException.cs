﻿namespace NadekoBot.Modules.NSFW.Exceptions
{
}
